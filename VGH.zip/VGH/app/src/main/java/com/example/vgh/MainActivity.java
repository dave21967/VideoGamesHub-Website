package com.example.vgh;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.example.vgh.MyWebViewClient;

public class MainActivity extends AppCompatActivity {
    WebView view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        view = (WebView)findViewById(R.id.webview);
        view.loadUrl("https://videogameshubit.pythonanywhere.com/");
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        view.setWebViewClient(new WebViewClient(){

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon)
            {
                // Here you can check your new URL.
                Log.e("URL", url);
                super.onPageStarted(view, url, favicon);
            }

        });
    }

    public void onBackPressed() {
        if(view.canGoBack()) {
            view.goBack();
        }
        else {
            return;
        }
    }
}
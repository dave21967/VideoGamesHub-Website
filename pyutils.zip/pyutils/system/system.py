import psutil

class System(object):
    def __init__(self):
        self._memory = psutil.virtual_memory()

    def get_cpu_max_frequency(self):
        return psutil.cpu_freq().max

    def get_cpu_min_frequency(self):
        return psutil.cpu_freq().min

    def get_cpu_current_frequency(self):
        return psutil.cpu_freq().current

    def get_memory_used(self, decimal=2):
        return round(self._get_size(self._memory.used), decimal)
    
    def get_memory_available(self, decimal=2):
        return round(self._get_size(self._memory.available), decimal)

    def get_memory_total(self, decimal=2):
        return round(self._get_size(self._memory.total), decimal)

    def get_memory_percent(self):
        return self._memory.percent

    def _get_size(self, bytes):
        while bytes > 1024:
            bytes /= 1024
        return bytes
from files.file import File, FileModeError
import json

class JSONFile(File):
    def __init__(self, name, mode):
        super().__init__(name, mode)

    def save(self):
        if self.__mode == 'w' or self.__mode == 'a':
            json.dump(data, self.__fp, indent=indent)
        else:
            raise FileModeError("Errore: modalità di apertura file errata!")

    def load(self):
        if self.__mode == 'r':
            return json.load(self.__fp)
        else:
            raise FileModeError("Errore: modalità di apertura file errata!")
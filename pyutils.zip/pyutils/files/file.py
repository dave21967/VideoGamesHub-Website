import pickle
import json

class FileModeError(Exception):
    pass

class File():
    def __init__(self, filename, mode):
        self.__filename = filename
        self.__mode = mode
        self.__fp = open(self.__filename, self.__mode)

    def set_filename(self, fn):
        self.__filename = fn

    def get_filename(self):
        return self.__filename

    def store_text(self, content):
        if self.__mode == 'w' or self.__mode == 'a':
            self.__fp.write(content)
        else:
            raise FileModeError("Errore: modalità apertura file errata!")

    def read_text(self):
        if self.__mode == 'r':
                return self.__fp.read()
        else:
            raise FileModeError("Errore: modalità apertura file errata!")

    @staticmethod
    def exists(filename):
        try:
            with open(filename, "r"):
                return True
        except FileNotFoundError:
            return False

    def store_obj(self, obj):
        if self.__mode == 'wb':
            pickle.dump(obj, self.__fp)
        else:
            raise FileModeError("Errore: modalità di apertura file errata!")

    def read_obj(self):
        if self.__mode == 'rb':
            return pickle.load(self.__fp)
        else:
            raise FileModeError("Errore: modalità di apertura file errata!")

    def close(self):
        self.__fp.close()
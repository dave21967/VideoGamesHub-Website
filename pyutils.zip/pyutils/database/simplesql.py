import sqlite3

class SQLite():
    def __init__(self, db):
        self.__db = sqlite3.connect(db)
        self.__cursor = self.__db.cursor()

    def create(self, table_name, args):
        self.__cursor.execute("CREATE TABLE "+table_name+" ("+args+")")

    def insert(self, table, values):
        query = "INSERT INTO "+table+" VALUES ("
        for i in range(len(values)):
            if i == len(values)-1:
                query += "?"
            else:
                query += "?,"
        query += ")"
        self.__cursor.execute(query, values)

    def select(self, query):
        self.__cursor.execute(query)
        return self.__cursor.fetchall()

    def delete(self, query):
        self.__cursor.execute(query)

    def update(self, query):
        self.__cursor.execute(query)

    def commit(self):
        self.__db.commit()

    def close(self):
        self.__db.close()
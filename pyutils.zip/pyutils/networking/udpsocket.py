import socket

class UDPSocket():
    def __init__(self):
        self.__socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    def recv_pkt(self, buff):
        return decode_packet(self.__socket.recv(buff))

    def send_to(self, msg, addr):
        self.__socket.sendto(msg.encode(), addr)

    def recv_from(self, buff):
        data = self.__socket.recvfrom(buff)
        return data
    
    def close(self):
        self.__socket.close()
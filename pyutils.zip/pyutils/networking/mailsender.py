import smtplib

class MailSender():
    def __init__(self, username, passwd):
        self._user = username
        self._password = passwd
        self._mail = smtplib.SMTP("smtp.gmail.com", 587)
        self._mail.ehlo()
        self._mail.starttls()
        self._mail.login(self._user, self._password)

    def send_mail(self, dest_addr, obj, text):
        self._mail.sendmail(self._user, dest_addr, obj+"\n\n"+text)

    def close(self):
        self._mail.quit()
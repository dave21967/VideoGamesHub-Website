import pickle

def decode_packet(p):
    return pickle.loads(p)

class Packet():
    def __init__(self, flag):
        self._flag = flag
        self._data = ""

    def set_flag(self, f):
        self._flag = f

    def get_flag(self):
        return self._flag

    def set_data(self, d):
        self._data = d

    def get_data(self):
        return self._data

    def encode(self):
        return pickle.dumps(self)

class LoginPacket(Packet):
    def __init__(self, username, password=None):
        self.flag = "login"
        self._username = username
        self._password = password

    def set_username(self, u):
        self._username = u

    def set_password(self, p):
        self._password = p

    def get_username(self):
        return self._username

    def get_password(self):
        return self._password

class DataPacket(Packet):
    def __init__(self, flag):
        super().__init__(flag)
        self._data = {}

    def add_item(self, name, data):
        self._data[name] = data

    def get_item(self, name):
        return self._data[name]

class QueryPacket(Packet):
    def __init__(self, query):
        super().__init__("query")
        self._query = query

import socket

class TCPSocket():
    def __init__(self, ip, port):
        self.__ip = ip
        self.__port = port
        self.__protocol = protocol
        self.__socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    def listen(self, backlog):
        self.__socket.listen(backlog)

    def accept(self):
        return self.__socket.accept()

    def connect(self):
        self.__socket.connect((self.__ip, self.__port))

    def send(self, msg):
        self.__socket.send(msg.encode())

    def recv(self, buff):
        data = self.__socket.recv(buff)
        return data.decode()
    
    def recv_pkt(self, buff):
        return decode_packet(self.__socket.recv(buff))

    def send_to(self, msg, addr):
        self.__socket.sendto(msg.encode(), addr)

    def recv_from(self, buff):
        data = self.__socket.recvfrom(buff)
        return data
    
    def close(self):
        self.__socket.close()
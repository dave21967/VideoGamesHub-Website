import pygame
from pytmx import load_pygame, TiledTileLayer

class Tile(pygame.sprite.Sprite):
    def __init__(self, x, y, w, h):
        super().__init__()
        self.rect = pygame.Rect(x, y, w, h)
        self.x = x
        self.y = y
        self.rect.x = x
        self.rect.y = y

class TileMap():
    def __init__(self, filename):
        self.tmxdata = load_pygame(filename)
        self.width = self.tmxdata.width * self.tmxdata.tilewidth
        self.height = self.tmxdata.height * self.tmxdata.tileheight
        self.walls = pygame.sprite.Group()
        self.rect = None

    def draw(self, win):
        ti = self.tmxdata.get_tile_image_by_gid
        for layer in self.tmxdata.visible_layers:
            if isinstance(layer, TiledTileLayer):
                for x, y, gid in layer:
                    tile = ti(gid)
                    if tile:
                        win.blit(tile, (x*self.tmxdata.tilewidth, y*self.tmxdata.tileheight))

        for tile_object in self.tmxdata.objects:
            if tile_object.name == 'wall':
                self.walls.add(Tile(tile_object.x, tile_object.y, tile_object.width, tile_object.height))

    def make_map(self):
        temp_surface = pygame.Surface([self.width, self.height])
        self.rect = temp_surface.get_rect()
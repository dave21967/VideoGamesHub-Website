import pygame

class Sprite(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        pygame.sprite.Sprite.__init__(self)
        self._image=pygame.image.load(image)
        self._image = pygame.transform.scale(self._image, (64, 64))
        self._rect = self._image.get_rect()
        self._rect.x = x
        self._rect.y = y
        self._x = x
        self._y = y
        self._selected = False

    def set_selected(self, sel):
        self._selected = sel

    def contains(self, x, y):
        if self._rect.collidepoint(x, y):
            return True
        else:
            return False
    
    def is_selected(self):
        return self._selected

    def get_rect(self):
        return self._rect
    
    def set_x(self, x):
        self._x = x
        self._rect.x = x

    def set_y(self, y):
        self._y = y
        self._rect.y = y

    def get_position(self):
        return (self._x, self._y)

    def set_position(self, x, y):
        self.set_x(x)
        self.set_y(y)

    def set_center(self, pos):
        self._rect.center = pos

    def draw(self, win):
        if self._selected:
            pygame.draw.rect(win, (0,0,0), self._rect, 2)
        win.blit(self._image, self._rect)
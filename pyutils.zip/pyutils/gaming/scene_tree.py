import pygame

class SceneTree(object):
    def __init__(self):
        self.scenes = {

        }
        self.args = {

        }
        self.scene = None
    
    def add_scene(self, name, scene):
        self.scenes[name] = scene

    def get_scene(self, name):
        return self.scenes[name]

    def add_args(self, key, value):
        self.args[key] = value

    def get_args(self, key):
        return self.args[key]
    
    def remove_args(self, key):
        self.args[key] = None

    def set_scene(self, name):
        self.scene = self.scenes[name]
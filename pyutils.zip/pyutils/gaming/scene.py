import pygame

class Scene(object):
    def __init__(self, game, window):
        self.window = window
        self.game = game

    def _get_tree(self):
        return self.game.get_tree()

    def draw(self):
        pass

    def update(self):
        pass

    def mouse_pressed(self, event):
        pass

    def mouse_released(self, event):
        pass

    def key_pressed(self, event):
        pass

    def key_released(self, event):
        pass

    def key_typed(self, event):
        pass
import pygame

pygame.font.init()

class Button(pygame.sprite.Sprite):
    def __init__(self, text, x, y, w, h, color=(0, 0, 0), texture=None):
        self.text = text
        if texture:
            self.image = pygame.image.load(texture)
        else:
            self.image = pygame.Surface([w, h])
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.rect.width = w
        self.rect.height = h
        self.image.fill(color)
    
    def draw(self, win):
        font = pygame.font.SysFont("none", 20)
        text_surface = font.render(self.text, True, (255, 255, 255))
        win.blit(self.image, (self.rect.x, self.rect.y))
        win.blit(text_surface, (self.rect.x+10, self.rect.y+10))
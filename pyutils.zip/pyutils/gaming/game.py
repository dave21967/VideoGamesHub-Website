import pygame
import sys
from py_utils.files.file import File
from py_utils.networking.packet import Packet
from py_utils.gaming.scene_tree import SceneTree

class Game(object):
    def __init__(self, title, width, height):
        self.window = pygame.display.set_mode((width, height))
        pygame.display.set_caption(title)
        self.width = width
        self.height = height
        self.clock = pygame.time.Clock()
        self.paused = False
        self.tree = SceneTree()

    def get_tree(self):
        return self.tree

    def update(self):
        self.tree.scene.update()

    def draw(self, fill=(255, 255, 255)):
        self.window.fill(fill)
        self.tree.scene.draw()
        pygame.display.flip()

    def tick(self, frame):
        self.clock.tick(frame)

    def run(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    self.tree.scene.mouse_pressed(event)
                if event.type == pygame.MOUSEBUTTONUP:
                    self.tree.scene.mouse_released(event)
                if event.type == pygame.KEYDOWN:
                    self.tree.scene.key_typed(event)
                    self.tree.scene.key_pressed(event)
                if event.type == pygame.KEYUP:
                    self.tree.scene.key_released(event)

            if not self.paused:
                self.tick(60)
                self.update()
                self.draw()

    def quit(self):
        pygame.quit()
        sys.exit()
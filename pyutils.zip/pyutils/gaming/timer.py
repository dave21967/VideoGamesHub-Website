from threading import Thread
import time

class Timer(Thread):
    def __init__(self, wait_time):
        super().__init__()
        self.wait_time = wait_time
        self.started = False
        self.paused = False

    def run(self):
        self.started = True
        while self.started:
            if self.wait_time > 0 and not self.paused:
                self.wait_time -= 1
                time.sleep(1)

    def stop(self):
        self.started = False

    def restart(self):
        self.paused = False

    def pause(self):
        self.paused = True
import pygame

class InputField():
    def __init__(self, x, y, w, h, font_size=30, place_holder=""):
        self.text = ""
        self.place_holder = place_holder
        self.font = pygame.font.SysFont("none", font_size)
        self.text_surface = self.font.render(self.place_holder+self.text, True, (0, 0, 0))
        self.rect = pygame.Rect(x, y, w, h)
        self.rect.x = x
        self.rect.y = y
        self.rect.width = w
        self.rect.height = h
        self.is_focused = False

    def draw(self, win):
        if not self.is_focused:
            pygame.draw.rect(win, (0, 0, 0), self.rect, 2)
        else:
            pygame.draw.rect(win, (128, 128, 128), self.rect, 2)
        self.text_surface = self.font.render(self.place_holder+self.text, True, (0, 0, 0))
        self.rect.width = max(100, self.text_surface.get_width()+10)
        win.blit(self.text_surface, (self.rect.x+5, self.rect.y+5))

    def update(self, event):
        if event.key == pygame.K_BACKSPACE:
            self.text = self.text[:-1]
        else:
            self.text += event.unicode
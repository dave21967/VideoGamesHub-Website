import pygame

pygame.font.init()

class Label(pygame.sprite.Sprite):
    def __init__(self, text, x, y, font_size=40, color=(0, 0, 0)):
        self.text = text
        self.font = pygame.font.SysFont("none", font_size)
        self.text_surface = self.font.render(self.text, True, color)
        self.x = x
        self.y = y
        self.font_size = font_size
        self.color = color

    def draw(self, window):
        self.font = pygame.font.SysFont("none", self.font_size)
        self.text_surface = self.font.render(self.text, True, self.color)
        self.rect = self.text_surface.get_rect()
        window.blit(self.text_surface, (self.x, self.y))
